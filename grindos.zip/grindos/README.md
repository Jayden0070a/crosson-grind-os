# GRIND OS

Your personal productivity app.

## Deploy to Vercel
1. Push this folder to GitHub
2. Import repo in Vercel
3. Deploy — done.
